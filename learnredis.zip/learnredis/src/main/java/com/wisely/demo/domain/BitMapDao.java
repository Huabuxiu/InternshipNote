package com.wisely.demo.domain;



import com.wisely.demo.Util.bloomfilter.BloomFilterHelper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.*;


/**
 * @program: learnredis
 * @description:
 * @author: Huabuxiu
 * @create: 2019-08-12 16:53
 **/
@Repository
@PropertySource("classpath:application.properties")
public class BitMapDao {

    @Value("${boomfilter.bitmap}")
    private String bitmap;

    @Value("${boomfilter.range}")
    private  int range;


    private static final String  Separate = ":";
    private static final String Lock = "lock";

    @Resource(name = "redisTemplate")
    private ValueOperations<Object,Object> valOps;

    @Autowired
    private StringRedisTemplate redisTemplate;

    @Autowired
    BloomFilterHelper bloomFilterHelper;


    private List<String> bitMaplist;

    private String Multiple = "Multiple";

    private int MultipleLocate;

    private String count  = "count";

    @PostConstruct
    public void init() {
        //初始化倍数
        if (valOps.get(Multiple)==null){
            valOps.set(Multiple,0);
            MultipleLocate = 0;
        }else {
            MultipleLocate = (int) valOps.get(Multiple);
        }
        //初始化bitmap的list
        if (valOps.get(bitmap) == null){
            bitMaplist = new ArrayList<String>();
            bitMaplist.add(bitmap + "-" + MultipleLocate);
            valOps.set(bitmap,bitmap + "-" + MultipleLocate + Separate);
        }else {
            bitMaplist = getBitMaplistFromCatch();
        }

        //初始化一下count
        if (valOps.get(count) == null){
            valOps.set(count,0);
        }

    }



    /**
    * @Description: 转化字符串成列表
    * @Param:
    * @return:
    * @Author: Huabuxiu
    * @Date: 2019-08-23
    */
    private List<String> getBitMaplistFromCatch(){
        String localString = (String) valOps.get(bitmap);
        String[] bitmapkeys = localString.split(Separate);
        return new ArrayList<>(Arrays.asList(bitmapkeys));
    }



    /**
     * @Description: 把字符串放入缓存
     * @Param: [query]
     * @return: void
     * @Author: Huabuxiu
     * @Date: 2019-08-13
     */
    public void putQueryInCache(String query){

        int[] ipoffset = hash(query);
        for (int i = 0 ; i < ipoffset.length ; i++){
            putBitInCache(bitMaplist.get(MultipleLocate),ipoffset[i],true);
        }
        valOps.increment(count);


        if ((range * 0.95) <= (int)valOps.get(count)){
        //扩容需要加并发锁
            synchronized(Lock) {
                if ((range * 0.95) <= (int) valOps.get(count)) {  //双重检验锁
                    //倍数自加
                    MultipleLocate++;
                    valOps.increment(Multiple);
                    //本地list增加扩容的一个bitmap
                    bitMaplist.add(bitmap + "-" + MultipleLocate);
                    //Redis增加一个
                    valOps.set(bitmap, valOps.get(bitmap) + bitmap + "-" + MultipleLocate + Separate);
                    valOps.set(count, 0);
                }
            }
        }
    }



    /**
    * @Description: 查询字符串是否在缓存中
     * 判断每个都在
    * @Param:query
    * @return:
    * @Author: Huabuxiu
    * @Date: 2019-08-13
    */
    public boolean IsinCache(String query){
        //初始化成全true
        boolean[] flags = new boolean[bitMaplist.size()];
        for (int i = 0; i< flags.length ; i++){
            flags[i] = true;
        }

        int[] ipoffset = hash(query);
        for (int i =0 ; i< bitMaplist.size(); i++) {   //遍历每一个都不存在就不存在
            for (int offset : ipoffset) {
                if (!valOps.getBit(bitMaplist.get(i), offset)) {
                    flags[i] = false;
                    break;
                }
            }
        }

        for (boolean flag : flags){
            if (flag)
                return true;
        }
        return false;
    }

    /**
     * 获取 Bit
     * @param key
     * @return
     */
    public String getBitFromCache(String key){
        return (String) valOps.get(key);
    }


    /**
     * key 键对应的值 value 对应的 ascii 码,在 offset 的位置(从左向右数) 变为 value。
     * @param key
     * @param offset
     * @param value
     */
    public void putBitInCache(String key, long offset, boolean value) {
       valOps.setBit(key,offset,value);
    }

    /**
     * 判断指定的位置 ASCII 码的 bit 位是否为1。
     * @param key
     * @param offset
     * @return
     */
    public boolean getBitFromCache(String key, int offset){
        return valOps.getBit(key,offset);
    }



    /**
    * @Description:哈希算法
    * @Param:把字符串映射成8个位置
    * @return:
    * @Author: Huabuxiu
    * @Date: 2019-08-12
    */
    public int[] hash(String ipport){
        try {
           return bloomFilterHelper.murmurHashOffset(ipport);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }




}
