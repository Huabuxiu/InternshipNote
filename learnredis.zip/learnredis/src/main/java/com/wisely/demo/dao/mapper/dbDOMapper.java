package com.wisely.demo.dao.mapper;

import com.wisely.demo.dao.dbDO;
import com.wisely.demo.dao.dbDOExample;
import java.util.List;

import org.apache.ibatis.annotations.*;
import org.apache.ibatis.session.RowBounds;

@Mapper
public interface dbDOMapper {
    int countByExample(dbDOExample example);

    int deleteByExample(dbDOExample example);

    @Delete({
        "delete from db_test",
        "where id = #{id,jdbcType=INTEGER}"
    })
    int deleteByPrimaryKey(Integer id);

    @Insert({
        "insert into db_test (name, value)",
        "values (#{name,jdbcType=VARCHAR}, #{value,jdbcType=VARCHAR})",
        " on duplicate key update value = #{value,jdbcType=VARCHAR}"
    })
    @SelectKey(statement="SELECT LAST_INSERT_ID()", keyProperty="id", before=false, resultType=Integer.class)
    int insert(dbDO record);

    int insertSelective(dbDO record);

    List<dbDO> selectByExampleWithRowbounds(dbDOExample example, RowBounds rowBounds);

    List<dbDO> selectByExample(dbDOExample example);

    @Select({
        "select",
        "id, name, value",
        "from db_test",
        "where id = #{id,jdbcType=INTEGER}"
    })
//    @ResultMap("BaseResultMap")
    dbDO selectByPrimaryKey(Integer id);


    @Select({
            "select",
            "id,name, value",
            "from db_test",
            "where name = #{name,jdbcType=VARCHAR}"
    })
    dbDO selectByName(String name);

    int updateByExampleSelective(@Param("record") dbDO record, @Param("example") dbDOExample example);

    int updateByExample(@Param("record") dbDO record, @Param("example") dbDOExample example);

    int updateByPrimaryKeySelective(dbDO record);

    @Update({
        "update db_test",
        "set name = #{name,jdbcType=VARCHAR},",
          "value = #{value,jdbcType=VARCHAR}",
        "where id = #{id,jdbcType=INTEGER}"
    })
    int updateByPrimaryKey(dbDO record);

    @Update({
            "update db_test",
            "set value = #{value,jdbcType=VARCHAR}",
            "where name = #{name,jdbcType=VARCHAR}"
    })
    int updateByName(String name ,String value);
}