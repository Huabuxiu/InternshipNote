package com.wisely.demo.web;




import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;
import com.wisely.demo.Util.bloomfilter.BoomFilterUtil;
import com.wisely.demo.cache.CacheHandler;
import com.wisely.demo.dao.dbDO;
import com.wisely.demo.dao.mapper.dbDOMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Random;
import java.util.concurrent.TimeUnit;

@RestController
public class MySqlController {

    @Autowired
    dbDOMapper dbDOMapper;

    @Resource(name = "redisTemplate")
    private ValueOperations<String,String> valOps;


    @Autowired
    BoomFilterUtil boomFilterUtil;

    @Autowired
    CacheHandler cacheHandler;


    @RequestMapping("/dbtest")
    public String  testhttp(HttpServletRequest request){
        try {
//            setUpDB(30000);
//            pressureUpdateTest(30000);
            pressureQueryTest(30000);
//            pressureInsertTest(30000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "测试查询";
    }


    public String testDb(String testString){
        return "DB 结果 " + dbDOMapper.selectByName(testString).getValue()
                + "\n布隆结果 "+boomFilterUtil.iSInCahe(testString)
                + "\n 缓存结果 "+valOps.get(testString);
    }


    public void setData(){
        String queryValue = "1234";
        String queryString =  boomFilterUtil.getQueryString(boomFilterUtil.getId(Integer.valueOf(queryValue)));


         /*
        在过滤器中增加
         */
        boomFilterUtil.putStringToCache(queryString);

        /*
        在数据库中增加
         */
        dbDO dbtest = new dbDO();
        dbtest.setName(queryString);
        dbtest.setValue(queryValue);
        dbDOMapper.insert(dbtest);

        /*
        在缓存中添加
         */
        valOps.set(queryString,queryValue);
    }



    //初始化测试数据
    public void setUpDB(int range) throws Exception {
        int i =0;
        while (i< range) {
            cacheHandler.putValue(boomFilterUtil.getQueryString(boomFilterUtil.getId(i)),String.valueOf(i));
            i++;
            if (i % 1000 == 0 && i > 1000){
                System.out.println("插入了" + i + "条请求");
            }
        }
    }


    public void pressureQueryTest(int range){
        Random random = new Random();
        int value = random.nextInt(range);
        String name = boomFilterUtil.getQueryString(boomFilterUtil.getId(value));
        System.out.println(cacheHandler.getValue(name));
    }

    public void pressureUpdateTest(int range) throws Exception {
        Random random = new Random();
        int value = random.nextInt(range);
        String name = boomFilterUtil.getQueryString(boomFilterUtil.getId(value));
        cacheHandler.updateValue(name,String.valueOf(value+random.nextInt(500)));
    }

    public void pressureInsertTest(int range)throws Exception{
        Random random = new Random();
        int value = random.nextInt(range);
        String name = boomFilterUtil.getQueryString(boomFilterUtil.getId(value));
        cacheHandler.putValue(name,String.valueOf(value));
    }
}
