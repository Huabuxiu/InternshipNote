package com.wisely.demo.web;


import com.wisely.demo.dao.Person;
import com.wisely.demo.domain.PersonDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DataController {

    @Autowired
    private PersonDao personDao;

    @RequestMapping("/set")
    public void set(){
        Person person =new Person("1","wyf",22);
        personDao.save(person);
        personDao.stringRedisTemplateDemo();;
    }

    @RequestMapping("/getString")
    public String getString(){
        return personDao.getString();
    }

    @RequestMapping("/getPerson")
    public Person getPerson(){
        return personDao.getPerson();
    }



}
