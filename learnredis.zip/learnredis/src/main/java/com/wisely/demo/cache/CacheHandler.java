package com.wisely.demo.cache;

import com.wisely.demo.Util.bloomfilter.BoomFilterUtil;
import com.wisely.demo.dao.dbDO;
import com.wisely.demo.dao.mapper.dbDOMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.concurrent.TimeUnit;

/**
 * @program: learnredis
 * @description:
 * @author: Huabuxiu
 * @create: 2019-08-20 16:14
 **/
@Component
public class CacheHandler implements Cache {

    private String NULLREDISVALUE = "nullValue";

    @Autowired
    dbDOMapper dbDOMapper;

    @Resource(name = "redisTemplate")
    private ValueOperations<String,String> valOps;

    @Autowired
    private StringRedisTemplate redisTemplate;

    @Autowired
    BoomFilterUtil boomFilterUtil;


    /**
    * @Description: 读取数据
    * @Param:  唯一标识
    * @return:
    * @Author: Huabuxiu
    * @Date: 2019-08-21
    */
    @Override
    public String getValue(String query) {
        String value;
        //判断是否在布隆里
        if (!boomFilterUtil.iSInCahe(query)){
           return "数据不存在";
        }
        if ((value = valOps.get(query)) != null) {
            return value;
        }else {
            dbDO dbResult;
            if ((dbResult = dbDOMapper.selectByName(query))== null){    //过滤器漏掉的情况
                valOps.set(query,NULLREDISVALUE, 30,TimeUnit.SECONDS);
                return "数据不存在";
            }
            value = dbResult.getValue();
            valOps.set(query,value,120, TimeUnit.SECONDS);//设置过期时间120秒
            return value;
        }
    }

    /**
    * @Description: 往数据库中插入
    * @Param:  插入的对象和缓存中的唯一标识
    * @return:
    * @Author: Huabuxiu
    * @Date: 2019-08-21
    */
    @Override
    public int putValue (String name, String value) throws Exception{
        dbDO dbtest = new dbDO();
        dbtest.setName(name);
        dbtest.setValue(value);
//        插入数据库
        dbDOMapper.insert(dbtest);
//        插入布隆过滤器
        boomFilterUtil.putStringToCache(name);
        return 0;
    }



    /**
* @Description: 更新操作
* @Param: 插入的对象和缓存中的唯一标识
* @return:
* @Author: Huabuxiu
* @Date: 2019-08-21
*/

    @Override
    public int updateValue(String name, String value)throws Exception{

        if (!redisTemplate.hasKey(name) || (redisTemplate.getExpire(name,TimeUnit.MILLISECONDS) <= 0)){
            dbDOMapper.updateByName(name,value);
            return 1;
        }else {
            dbDOMapper.updateByName(name,value);
            redisTemplate.delete(name);
            return 2;
        }
    }
}
