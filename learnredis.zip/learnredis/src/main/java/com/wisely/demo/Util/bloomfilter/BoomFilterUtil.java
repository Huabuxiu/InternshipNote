package com.wisely.demo.Util.bloomfilter;

import com.wisely.demo.domain.BitMapDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * @program: learnredis
 * @description:查询到请求存在是否
 * @author: Huabuxiu
 * @create: 2019-08-12 16:24
 **/

@Component
@PropertySource("classpath:application.properties")
public class BoomFilterUtil {

    @Value("${boomfilter.range}")
    private int range;


    @Autowired
    BitMapDao bitMapDao;




    private static final int MISS = 1500;
    private static final int HIT = 3500;
    private int query;
    private int testNum;
    private int theoryInNum ;
    private int actualInNum ;
    private int theorymiss ;
    private int actualmiss ;
    private long avrTime;



    public void putStringToCache(String value){
        bitMapDao.putQueryInCache(value);
    }


    public boolean iSInCahe(String key){
        return bitMapDao.IsinCache(key);
    }



    public void test1(){
        //存放缓存
        setQuery(30000);
//        setUpCache();
        //测试五千个请求
        testQuery(HIT,MISS);
        setTestNum(HIT+MISS);
        System.out.println(getResultString());
    }


    public void testQuery(int hit,int miss){

        Random random = new Random();
        setTheoryInNum(hit);
        setTheorymiss(miss);
        int num =0;
        int actualhit=0;
        int actualmiss=0;

        Long currTime = System.currentTimeMillis();
        while (num < hit){
            if (bitMapDao.IsinCache(getQueryString(getId(random.nextInt(range))))){
                actualhit++;
            }
            num++;
        }

        num = 0;
        setActualInNum(actualhit);
        while (num < miss)
        {
            String outQuery = getErrorQueryString();
            if (!bitMapDao.IsinCache(outQuery)){
                actualmiss++;
            }
            num++;
        }
        avrTime = (System.currentTimeMillis() - currTime)/(hit+miss);
        setActualmiss(actualmiss);

    }



    /**
     * @Description: 放入30万请求到缓存里去
     * @Param: []
     * @return: void
     * @Author: Huabuxiu
     * @Date: 2019-08-13
     */
    public void setUpCache(){
        int i =0;
        while (i< range) {
            bitMapDao.putQueryInCache(getQueryString(getId(i)));
            i++;
            if (i % 1000 == 0 && i > 1000){
                System.out.println("插入了" + i + "条请求");
            }
        }
        setQuery(i);
    }


public String getId(int id){
        if (String.valueOf(id).length() < 10){
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < (10 -String.valueOf(id).length()) ;i++){
                sb.append("0");
            }
            return sb.append(id).toString();
        }else {
            return String.valueOf(id);
        }
}



    public String getErrorQueryString(){
        Random random = new Random();
        String shopId;
        StringBuilder sb = new StringBuilder();
        int i=0;
        int num;
        while (i<10){
            if ( (num = random.nextInt(10)) > 3){ sb.append(num); }
            i++;
        }
        while (sb.length()<10){
            sb.append(0);
        }
        shopId = sb.toString();
        return  "GrayShop_%"+shopId+"%:  { gray : 1}";
    }


    public String getQueryString(String shopId){
        return  "GrayShop_%"+shopId+"%:  { gray : 1}";
    }

    public void setTheorymiss(int theorymiss) {
        this.theorymiss = theorymiss;
    }

    public void setActualmiss(int actualmiss) {
        this.actualmiss = actualmiss;
    }

    public int getQuery() {
        return query;
    }

    public void setQuery(int query) {
        this.query = query;
    }

    public int getTestNum() {
        return testNum;
    }

    public void setTestNum(int testNum) {
        this.testNum = testNum;
    }

    public int getTheoryInNum() {
        return theoryInNum;
    }

    public void setTheoryInNum(int theoryInNum) {
        this.theoryInNum = theoryInNum;
    }

    public int getActualInNum() {
        return actualInNum;
    }

    public void setActualInNum(int actualInNum) {
        this.actualInNum = actualInNum;
    }

    public String getResultString(){

        Double aDouble = Double.valueOf(Math.abs(actualmiss-theorymiss)/Double.valueOf(testNum));

        return "存放\t" + query + "\t个请求\n"
                + "测试访问\t" + testNum +"\t个请求 \n"
                + "理论存在\t" + theoryInNum +"\t个请求\n"
                + "实际存在\t" + actualInNum +"\t个请求\t"
                + "存在命中失误率\t" +(Math.abs(actualInNum-theoryInNum)/testNum)+"\n"
                + "理论不存在\t" + theorymiss +"\t个请求\n"
                + "实际不存在\t" + actualmiss +"\t个请求\t"
                + "不存在命中失误率\t" +aDouble+"\n"
                +"平均单次查询时间\t" +avrTime+"ms\n";
    }

}
