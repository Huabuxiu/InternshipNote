package com.wisely.demo.web;

import com.wisely.demo.Util.bloomfilter.BoomFilterUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @program: learnredis
 * @description:
 * @author: Huabuxiu
 * @create: 2019-08-12 17:12
 **/
@Controller
public class BoomFilterController {

    @Autowired
    BoomFilterUtil boomFilterUtil;

    @RequestMapping("/testFilter")
    @ResponseBody
    public String testFilter(){
//        boomFilterUtil.putStringToCache("this is a test");
//        System.out.println(boomFilterUtil.iSInCahe("this is a error test"));

        boomFilterUtil.test1();
        return "123";
    }



}
