package com.wisely.demo.cache;

/**
 * @program: learnredis
 * @description:
 * @author: Huabuxiu
 * @create: 2019-08-20 15:14
 **/
public interface Cache {

    public String getValue(String query);

    public int putValue(String name, String value) throws Exception;

    public int updateValue(String name,String value)throws Exception;
}
