package com.wisely.demo.Util.bloomfilter;

import org.junit.Test;

import java.util.Random;

import static org.junit.Assert.*;

public class BoomFilterUtilTest {
    Random random = new Random();

    @Test
    public void test1() {
        BoomFilterUtil util =  new BoomFilterUtil();
        System.out.println(util.getQueryString(util.getId(random.nextInt(300000))));
        System.out.println(util.getErrorQueryString());
    }
}