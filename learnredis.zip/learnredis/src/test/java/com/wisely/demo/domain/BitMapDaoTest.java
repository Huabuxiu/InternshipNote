package com.wisely.demo.domain;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.math.BigInteger;
import java.util.List;

import static org.junit.Assert.*;

@Repository
public class BitMapDaoTest {

    @Resource(name = "redisTemplate")
    private ValueOperations<Object,Object> valOps;

    @Autowired
    private RedisTemplate<Object,Object> redisTemplate;


    BitMapDao bitMapDao = new BitMapDao();

    @Test
    public void hash1() {
        bitMapDao.putQueryInCache("me.ele.soademo.api.SoademoService:goodbye");
        System.out.println();

    }

    @Test
    public void hash2() {
        String arg = "http://localhost:8080/->me.ele.soademo.api.SoademoService:goodbye";
        bitMapDao.putQueryInCache(arg);
        System.out.println(bitMapDao.getBitFromCache("ipportmap"));
        System.out.println(bitMapDao.getBitFromCache("servicemethodmap"));
    }

}