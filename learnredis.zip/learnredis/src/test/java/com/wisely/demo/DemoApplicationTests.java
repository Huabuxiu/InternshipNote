package com.wisely.demo;

import org.junit.Test;

import java.util.Random;
import java.util.UUID;


public class DemoApplicationTests {

    @Test
    public void contextLoads() {

        System.out.println(2000%1000);
    }

}
