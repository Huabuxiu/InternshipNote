createing a new branch is quick.
